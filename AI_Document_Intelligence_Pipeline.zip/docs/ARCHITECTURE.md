# Architecture

See README.md for overview.