def test_imports():
    import src.project4.pipeline as p
    assert hasattr(p, 'run_document_pipeline')
