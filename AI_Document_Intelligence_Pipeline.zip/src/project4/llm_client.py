import time, os
STUB_MODE = True if os.getenv('LLM_STUB', '1') == '1' else False
def call_llm(prompt: str, model: str = 'gpt-4o-mini') -> str:
    if STUB_MODE:
        time.sleep(0.1)
        return f"[STUB] {prompt[:200]}"
    raise RuntimeError('LLM real mode not implemented; set LLM_STUB=1 for stub runs') 
