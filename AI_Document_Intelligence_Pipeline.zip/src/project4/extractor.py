from pathlib import Path
import fitz  # PyMuPDF
import docx
def extract_text_pdf(path: str):
    doc = fitz.open(path)
    pages = []
    for i in range(len(doc)):
        page = doc[i]
        pages.append(page.get_text("text"))
    return "\n\n".join(pages)
def extract_text_docx(path: str):
    doc = docx.Document(path)
    paragraphs = [p.text for p in doc.paragraphs]
    return "\n".join(paragraphs)
def extract_text(path: str):
    p = Path(path)
    if p.suffix.lower() == ".pdf":
        return extract_text_pdf(str(p))
    if p.suffix.lower() in [".docx", ".doc"]:
        return extract_text_docx(str(p))
    return p.read_text(encoding="utf-8")
