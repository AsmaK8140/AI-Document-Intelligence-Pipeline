from pathlib import Path
import shutil, uuid
from datetime import datetime
DATA_ROOT = Path.cwd()
def ingest_file(src_path: str, dest_dir: str = "data/uploads"):
    src = Path(src_path)
    dest = DATA_ROOT / dest_dir
    dest.mkdir(parents=True, exist_ok=True)
    doc_id = f"doc_{uuid.uuid4().hex[:8]}"
    fname = f"{doc_id}__{src.name}"
    target = dest / fname
    shutil.copy(src, target)
    metadata = {
        "doc_id": doc_id,
        "filename": src.name,
        "stored_path": str(target),
        "uploaded_at": datetime.utcnow().isoformat()
    }
    return metadata
