from typing import List
def chunk_text_by_tokens(text: str, max_tokens: int = 800, overlap: int = 100) -> List[str]:
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk_words = words[i:i+max_tokens]
        chunks.append(' '.join(chunk_words))
        i += max_tokens - overlap
    return chunks
