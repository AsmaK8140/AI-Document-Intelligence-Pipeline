import numpy as np
def compute_embedding(text: str):
    return np.random.rand(768).astype('float32')
