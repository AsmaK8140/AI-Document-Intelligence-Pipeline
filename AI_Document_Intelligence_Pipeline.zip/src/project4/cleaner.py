import re
def clean_text(text: str) -> str:
    t = re.sub(r'\s+', ' ', text).strip()
    t = re.sub(r'\d{1,3}\s*\/\s*\d{1,3}', ' ', t)
    return t
