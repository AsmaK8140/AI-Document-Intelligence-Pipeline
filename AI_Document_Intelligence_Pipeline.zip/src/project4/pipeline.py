from pathlib import Path
import json
from .extractor import extract_text
from .cleaner import clean_text
from .chunker import chunk_text_by_tokens
from .prompt_templates import executive_summary_prompt, section_summary_prompt, entities_prompt, qa_generation_prompt
from .llm_client import call_llm
def run_document_pipeline(filepath: str, out_prefix: str = 'outputs/report'):
    text = extract_text(filepath)
    text = clean_text(text)
    chunks = chunk_text_by_tokens(text, max_tokens=800, overlap=100)
    sections = []
    for idx, chunk in enumerate(chunks):
        prompt = section_summary_prompt(chunk, idx)
        resp = call_llm(prompt)
        sections.append({'index': idx, 'summary': resp})
    exec_prompt = executive_summary_prompt(' '.join(chunks), {'source': filepath})
    exec_summary = call_llm(exec_prompt)
    entities = call_llm(entities_prompt(text))
    qa = call_llm(qa_generation_prompt(text))
    out = {
        'file': filepath,
        'executive_summary': exec_summary,
        'sections': sections,
        'entities': entities,
        'qa': qa
    }
    out_path = Path(f"{out_prefix}.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2, ensure_ascii=False))
    return str(out_path)
