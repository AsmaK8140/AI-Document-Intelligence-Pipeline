def aggregate_section_summaries(summaries):
    return {'sections': summaries}
