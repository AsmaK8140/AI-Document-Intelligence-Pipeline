def executive_summary_prompt(doc_text: str, meta: dict) -> str:
    return f"""Act as an executive summarizer.\nProduce an executive summary (4-6 lines) for the following document.\nMetadata: {meta}\nDocument:\n{doc_text}\n"""
def section_summary_prompt(chunk_text: str, idx: int) -> str:
    return f"Summarize this section (3-4 lines) and give key bullets. Section index: {idx}\n\n{chunk_text}"
def entities_prompt(text: str) -> str:
    return f"Extract named entities (PERSON, ORG, LOC, DATE, PRODUCT). Return as JSON array of {{type, text}}.\n\n{text}"
def qa_generation_prompt(text: str) -> str:
    return f"Generate 5 useful Q&A pairs (question, answer) from the following text:\n\n{text}"
