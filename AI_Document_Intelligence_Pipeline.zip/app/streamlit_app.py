import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))
import streamlit as st
from src.project4.ingestion import ingest_file
from src.project4.pipeline import run_document_pipeline
st.set_page_config(page_title='AI Document Intelligence', layout='wide')
st.title('AI Document Intelligence Pipeline — Pro')
with st.sidebar:
    st.header('Upload Document')
    uploaded = st.file_uploader('Choose a PDF/DOCX/TXT', type=['pdf','docx','txt'])
    if uploaded is not None:
        tmp = ROOT / 'data' / 'uploads'
        tmp.mkdir(parents=True, exist_ok=True)
        upath = tmp / uploaded.name
        with open(upath, 'wb') as f:
            f.write(uploaded.getbuffer())
        st.success(f'Saved {uploaded.name}')
        st.write('Processing...')
        out = run_document_pipeline(str(upath), out_prefix=str(ROOT / 'outputs' / uploaded.name))
        st.success(f'Done. Output: {out}')
if st.button('Run sample doc'):
    sample = ROOT / 'data' / 'sample_docs' / 'sample_doc_1.txt'
    if sample.exists():
        out = run_document_pipeline(str(sample), out_prefix=str(ROOT / 'outputs' / 'sample_doc_1'))
        st.success(f'Done. Output: {out}')
    else:
        st.info('No sample doc found.')
